# custom-tinymce
 Add some HTML format blocks to the TinyMCE
